package com.cg.bookauth.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity

public class Author {

	@Id
	@SequenceGenerator(name="seq1",sequenceName="ID_SEQ",initialValue=1,allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq1")
	private int id;
	
	@Column(name="author_name",length=30)
	private String name;

	@OneToMany(mappedBy="author",cascade=CascadeType.ALL)
	private Set<Book> books = new HashSet<>();	

	public Set<Book> getBooks() {
		return books;
	}

	public void setBooks(Set<Book> books) {
		this.books = books;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public void addBooks(Book book) {
		book.setAuthor(this);			//this will avoid nested cascade
		this.getBooks().add(book);
	}

	
	
}
