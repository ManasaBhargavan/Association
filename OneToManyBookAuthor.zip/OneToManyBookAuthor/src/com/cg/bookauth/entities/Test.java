package com.cg.bookauth.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import net.sf.cglib.proxy.Factory;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory entitymanagerfactory= Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager=entitymanagerfactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		//create a new author
		Author author=new Author();
		author.setName("XYZ");
		
		//create three instances of books
		Book b1 = new Book();
		b1.setTitle("M3");;
		b1.setPrice(800);
		
		Book b2 = new Book();
		b2.setTitle("Xy");;
		b2.setPrice(500);
		
		Book b3 = new Book();
		b3.setTitle("Mathematics");
		b3.setPrice(300);
		
		//add both books to author
		author.addBooks(b1);
		author.addBooks(b2);
		author.addBooks(b3);
		
		entityManager.persist(author);
		System.out.println("Added author with two books successfully");
		entityManager.getTransaction().commit();
		entityManager.close();
		entitymanagerfactory.close();
	}

}
