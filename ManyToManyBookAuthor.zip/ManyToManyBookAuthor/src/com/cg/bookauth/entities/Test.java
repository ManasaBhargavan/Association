package com.cg.bookauth.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import net.sf.cglib.proxy.Factory;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory entitymanagerfactory= Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager=entitymanagerfactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		//first define few authors
		Author a1=new Author();
		a1.setName("Kathy");
		
		Author a2=new Author();
		a2.setName("XYZ");
		
		//first define first book and add few auhtors
		Book b1=new Book();
		b1.setTitle("Java ");
		b1.setPrice(500);
		
		b1.addAuthor(a1);
		b1.addAuthor(a2);
		
		//define second book and few authors
		Book b2=new Book();
		b2.setTitle("Java Core");
		b2.setPrice(800);
		
		b2.addAuthor(a1);
		b2.addAuthor(a2);
		
		//save orders using entity manager
		entityManager.persist(b1);
		entityManager.persist(b2);
		
		System.out.println("Added books successfully");
		
		entityManager.getTransaction().commit();
		entityManager.close();
		entitymanagerfactory.close();
	}

}
