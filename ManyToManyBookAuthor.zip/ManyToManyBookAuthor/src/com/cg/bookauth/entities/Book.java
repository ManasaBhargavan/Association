package com.cg.bookauth.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="book_tbl")
public class Book {

	@Id
	@GeneratedValue
	private int ISBN;
	
	@Column(name="book_title",length=10)
	private String title;
	
	@Column(name="book_price")
	private int price;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name = "book_author", joinColumns = { @JoinColumn(name = "ISBN")}, inverseJoinColumns = { @JoinColumn(name = "authorId") })
	private Set<Author> authors= new HashSet<>();
	
	public int getISBN() {
		return ISBN;
	}

	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	public void addAuthor(Author author){ 			//this will avoid nested cascade
		this.getAuthors().add(author);
	}

	public Set<Author> getAuthors() {
		return authors;
	}

	public void setAuthors(Set<Author> authors) {
		this.authors = authors;
	}
	
}
