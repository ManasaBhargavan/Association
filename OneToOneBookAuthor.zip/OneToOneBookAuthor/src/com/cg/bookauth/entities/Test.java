package com.cg.bookauth.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import net.sf.cglib.proxy.Factory;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory entitymanagerfactory= Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager=entitymanagerfactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		Book book=new Book();
		book.setTitle("Java");
		book.setPrice(500);
		Author author=new Author();
		author.setName("Kathy");
		
		book.setAuthor(author);
		
		entityManager.persist(book);
		entityManager.persist(author);
		System.out.println("Added successfully");
		entityManager.getTransaction().commit();
		entityManager.close();
		entitymanagerfactory.close();
	}

}
